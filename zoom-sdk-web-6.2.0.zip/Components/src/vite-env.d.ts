
/// <reference types="vite/client" />


